import torch
import torch.nn as nn


class AsymmetricLoss(nn.Module):
    """Asymmetric Loss (Ridnik et al., ICCV 2021). 쉬운 음성 샘플의 loss를 줄여 희귀 클래스 학습을 돕는다."""

    def __init__(self, gamma_neg=4.0, gamma_pos=0.0, clip=0.05, eps=1e-8):
        super().__init__()
        self.gamma_neg, self.gamma_pos, self.clip, self.eps = gamma_neg, gamma_pos, clip, eps

    def forward(self, logits, targets):
        p = torch.sigmoid(logits.float())
        p_neg = (p - self.clip).clamp(min=0) if self.clip > 0 else p
        loss_pos = targets * torch.log(p.clamp(min=self.eps)) * (1 - p) ** self.gamma_pos
        loss_neg = (1 - targets) * torch.log((1 - p_neg).clamp(min=self.eps)) * p_neg ** self.gamma_neg
        return -(loss_pos + loss_neg).sum(1).mean()


def build_loss(name):
    if name == "bce":
        return nn.BCEWithLogitsLoss()
    if name == "asl":
        return AsymmetricLoss()
    raise ValueError(name)
