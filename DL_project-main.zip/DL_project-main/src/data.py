import os

import numpy as np
import pandas as pd
import torch
from PIL import Image, ImageOps
from torch.utils.data import Dataset
from torchvision import transforms

IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".bmp")
MEAN = (0.485, 0.456, 0.406)
STD = (0.229, 0.224, 0.225)
PAD_COLOR = tuple(int(m * 255) for m in MEAN)  # 정규화하면 0에 가까워지는 회색


def load_image(path):
    """A 전처리 ①②: EXIF 회전 보정 + RGB 변환.
    흑백(L), 팔레트(P), 투명 배경(RGBA/LA) 이미지도 모두 3채널 RGB로 맞춘다."""
    img = Image.open(path)
    img = ImageOps.exif_transpose(img)  # 폰 사진이 옆으로 누운 채 들어가는 것 방지
    if img.mode == "P":
        img = img.convert("RGBA")
    if img.mode in ("RGBA", "LA"):
        # 투명한 부분은 흰 배경으로 채운다 (그냥 RGB로 바꾸면 검게 나올 수 있음)
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img.convert("RGBA"), mask=img.convert("RGBA").split()[-1])
        return bg
    return img.convert("RGB")


class Letterbox:
    """A 전처리 ③: 가로세로 비율을 유지한 채 긴 변을 size에 맞추고, 남는 부분은 여백으로 채워 정사각형으로 만든다.
    정사각형으로 강제로 늘리면 사람이 찌그러지고, center crop은 가장자리 물건(신발, 모자)이 잘린다."""

    def __init__(self, size, fill=PAD_COLOR):
        self.size, self.fill = size, fill

    def __call__(self, img):
        w, h = img.size
        scale = self.size / max(w, h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        img = img.resize((nw, nh), Image.BICUBIC)
        canvas = Image.new("RGB", (self.size, self.size), self.fill)
        canvas.paste(img, ((self.size - nw) // 2, (self.size - nh) // 2))
        return canvas


def load_categories(path):
    with open(path, encoding="utf-8") as f:
        cats = [line.strip() for line in f if line.strip()]
    assert len(cats) == 27, f"{path}: expected 27 categories, got {len(cats)}"
    return cats


def load_split(split_dir, categories):
    """split_dir/labels.csv -> (파일명 리스트, (N, 27) float32 타깃)."""
    df = pd.read_csv(os.path.join(split_dir, "labels.csv"), encoding="utf-8-sig")
    files = df["file_name"].tolist()
    targets = df[categories].to_numpy(dtype=np.float32)
    return files, targets


def build_transforms(img_size, train, aug=None):
    """A 전처리(항상 적용): Letterbox -> Tensor -> ImageNet 정규화.
    train일 때는 B 단계 증강(src/augment.py)이 Letterbox 앞에 붙는다. aug 는 parse_aug 결과(set).
    aug 가 비어 있으면 Letterbox + 좌우반전만 = 베이스라인."""
    tail = [transforms.ToTensor(), transforms.Normalize(MEAN, STD)]
    if not train:
        return transforms.Compose([Letterbox(img_size)] + tail)
    from src.augment import TrainPipeline, build_train_steps  # augment 가 data 를 import 하므로 여기서 import
    return transforms.Compose([TrainPipeline(build_train_steps(img_size, aug or set()))] + tail)


class LabeledImages(Dataset):
    def __init__(self, split_dir, categories, transform, mosaic=None):
        """mosaic: src.augment.Mosaic (train 에서 --aug mosaic 일 때만). None 이면 한 장씩 그대로."""
        self.image_dir = os.path.join(split_dir, "images")
        self.files, self.targets = load_split(split_dir, categories)
        self.transform = transform
        self.mosaic = mosaic

    def __len__(self):
        return len(self.files)

    def path(self, i):
        return os.path.join(self.image_dir, self.files[i])

    def __getitem__(self, i):
        if self.mosaic is not None:
            img, target = self.mosaic(self, i)  # 다른 이미지와 붙이면 라벨도 합집합으로 바뀜
        else:
            img, target = load_image(self.path(i)), self.targets[i]
        return self.transform(img), torch.from_numpy(np.asarray(target, dtype=np.float32))


class FolderImages(Dataset):
    """라벨 없는 이미지 폴더 (predict.py 용)."""

    def __init__(self, image_dir, transform):
        self.image_dir = image_dir
        self.files = sorted(f for f in os.listdir(image_dir) if f.lower().endswith(IMAGE_EXTS))
        self.transform = transform

    def __len__(self):
        return len(self.files)

    def __getitem__(self, i):
        img = load_image(os.path.join(self.image_dir, self.files[i]))
        return self.transform(img), os.path.splitext(self.files[i])[0]


def rare_class_weights(targets, power=0.5, max_weight=5.0):
    """이미지별 샘플링 가중치: 이미지에 있는 클래스 중 가장 희귀한 클래스 기준.
    weight = (최다 클래스 빈도 / 그 클래스 빈도) ** power, max_weight로 상한."""
    freq = targets.sum(0)
    cls_w = (freq.max() / np.maximum(freq, 1)) ** power
    img_w = (targets * cls_w[None, :]).max(1)
    img_w[targets.sum(1) == 0] = 1.0
    return np.minimum(img_w, max_weight)
