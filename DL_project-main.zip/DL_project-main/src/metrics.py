import numpy as np


def micro_f1(pred, gt):
    tp = (pred & gt).sum()
    fp = (pred & ~gt).sum()
    fn = (~pred & gt).sum()
    return 2 * tp / max(2 * tp + fp + fn, 1)


def per_class_f1(pred, gt):
    tp = (pred & gt).sum(0)
    fp = (pred & ~gt).sum(0)
    fn = (~pred & gt).sum(0)
    denom = 2 * tp + fp + fn
    # 정답에도 예측에도 없는 클래스는 1점 처리
    return np.where(denom > 0, 2 * tp / np.maximum(denom, 1), 1.0)


def macro_f1(pred, gt):
    return per_class_f1(pred, gt).mean()


def imagewise_f1(pred, gt):
    tp = (pred & gt).sum(1)
    denom = pred.sum(1) + gt.sum(1)
    # 예측과 정답이 모두 비어 있으면 1점
    return np.where(denom > 0, 2 * tp / np.maximum(denom, 1), 1.0).mean()


def all_metrics(probs, targets, thresholds):
    pred = probs >= np.asarray(thresholds)[None, :]
    gt = targets.astype(bool)
    return {
        "micro_f1": float(micro_f1(pred, gt)),
        "macro_f1": float(macro_f1(pred, gt)),
        "imagewise_f1": float(imagewise_f1(pred, gt)),
    }


def tune_thresholds(probs, targets, grid=np.arange(0.05, 0.951, 0.05)):
    """클래스마다 F1이 최대가 되는 threshold. 양성 샘플이 없는 클래스는 0.5."""
    gt = targets.astype(bool)
    th = np.full(probs.shape[1], 0.5)
    for c in range(probs.shape[1]):
        if gt[:, c].sum() == 0:
            continue
        scores = [per_class_f1((probs[:, c] >= t)[:, None], gt[:, c][:, None])[0] for t in grid]
        th[c] = grid[int(np.argmax(scores))]
    return th
