import timm
import torch


def build_model(name, num_classes=27, pretrained=False):
    return timm.create_model(name, pretrained=pretrained, num_classes=num_classes)


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def save_checkpoint(path, model, model_name, img_size, categories, thresholds):
    torch.save({
        "model_name": model_name,
        "img_size": img_size,
        "categories": categories,
        "thresholds": [float(t) for t in thresholds],
        "state_dict": model.state_dict(),
    }, path)


def load_checkpoint(path, device="cpu"):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    # pretrained=False: 인터넷 없이 로드 (가중치는 체크포인트에 전부 들어 있음)
    model = build_model(ckpt["model_name"], len(ckpt["categories"]), pretrained=False)
    model.load_state_dict(ckpt["state_dict"])
    return model.to(device).eval(), ckpt
