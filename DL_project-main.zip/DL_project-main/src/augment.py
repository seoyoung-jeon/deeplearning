"""B 단계: 학습 때만 쓰는 augmentation (뼈대).

계획은 docs/PREPROCESSING.md 의 B 표를 따른다. train.py --aug 로 켜고 끈다.
    --aug none                     지금과 똑같음 (A 전처리 + 좌우반전) = 베이스라인
    --aug color,gray,degrade       ① 색 · 흑백 · 저화질
    --aug color,gray,degrade,letterbox          + ② 랜덤 letterbox
    --aug color,gray,degrade,letterbox,mosaic,crop   + ③ 모자이크 · 약한 crop

적용 순서 (모두 letterbox 직전, 원본 비율 이미지 상태에서):
    [데이터셋] mosaic -> [TrainPipeline] crop -> hflip -> color -> gray -> degrade -> letterbox -> ToTensor -> Normalize

TODO(A1): 아래 NotImplementedError 부분을 하나씩 채운다.
    아직 안 채운 증강을 --aug 로 켜면 바로 에러가 나도록 해 두었다.
    (조용히 아무것도 안 하고 학습되면 실험 기록이 틀어지기 때문)
    하나 채울 때마다 tools/preview_preprocess.py 로 눈으로 확인 -> PC에서 smoke test -> push.
"""
import random

from PIL import Image
from torchvision import transforms

from src.data import PAD_COLOR, Letterbox, load_image

AUG_NAMES = ("mosaic", "crop", "color", "gray", "degrade", "letterbox")


def parse_aug(text):
    """'color,gray' -> {'color', 'gray'}. 'none' 또는 빈 문자열 -> 빈 set."""
    if not text or text.strip().lower() == "none":
        return set()
    names = {t.strip().lower() for t in text.split(",") if t.strip()}
    unknown = names - set(AUG_NAMES)
    if unknown:
        raise ValueError(f"알 수 없는 --aug 값: {sorted(unknown)} (가능: none, {', '.join(AUG_NAMES)})")
    return names


def is_mosaic(img):
    """Mosaic 이 만든 이미지인지. 모자이크 이미지에는 crop 을 안 하고, 랜덤 letterbox 의 s 범위도 다르다.
    주의: ColorJitter 등을 거치면 img.info 가 사라지므로 TrainPipeline 이 맨 처음에 한 번만 읽어서 넘겨준다."""
    return bool(img.info.get("mosaic", False))


class TrainPipeline:
    """train transform 묶음. torchvision Compose 와 같은데, 맨 처음에 모자이크 여부를 읽어서
    mosaic_aware = True 인 단계(WeakCrop, RandomLetterbox)에 mosaic=... 로 넘겨준다."""

    def __init__(self, steps):
        self.steps = steps

    def __call__(self, img):
        mosaic = is_mosaic(img)
        for step in self.steps:
            img = step(img, mosaic=mosaic) if getattr(step, "mosaic_aware", False) else step(img)
        return img


# ---------------------------------------------------------------------------
# ③ 모자이크 (데이터셋 단계: 이미지 2장 이상과 라벨이 필요해서 transform 이 아니라 데이터셋에서 호출)
# ---------------------------------------------------------------------------
class Mosaic:
    """p 확률로 train 이미지 2장을 높이를 맞춰 가로로 붙인다. 가끔(p_grid) 4장을 2x2 격자로.
    라벨은 합집합(OR). 결과 이미지에는 img.info['mosaic'] = True 를 달아 둔다."""

    def __init__(self, p=0.3, p_grid=0.2):
        self.p, self.p_grid = p, p_grid

    def __call__(self, ds, i):
        """ds: LabeledImages, i: 인덱스 -> (PIL 이미지, (27,) float32 타깃)"""
        img = load_image(ds.path(i))
        target = ds.targets[i]
        if random.random() >= self.p:
            return img, target
        # TODO(A1):
        #   j = random.randrange(len(ds)); other = load_image(ds.path(j))
        #   두 장을 같은 높이로 resize -> 가로로 이어 붙인 새 캔버스
        #   target = np.maximum(target, ds.targets[j])
        #   out.info["mosaic"] = True
        raise NotImplementedError("Mosaic 은 아직 구현 전이에요 (src/augment.py TODO)")


# ---------------------------------------------------------------------------
# 이미지 한 장 단위 증강 (transform)
# ---------------------------------------------------------------------------
class WeakCrop:
    """p 확률로 가로 w_range, 세로 h_range 비율만큼 남기고 자른다. 모자이크 이미지는 건너뜀.
    위아래를 덜 자르는 이유: 신발 · 모자가 잘려도 라벨은 남아서 오답을 가르치게 됨."""

    mosaic_aware = True

    def __init__(self, p=0.3, w_range=(0.88, 1.0), h_range=(0.95, 1.0)):
        self.p, self.w_range, self.h_range = p, w_range, h_range

    def __call__(self, img, mosaic=False):
        if mosaic or random.random() >= self.p:
            return img
        # TODO(A1): PIL img.crop((left, top, right, bottom)) 로 구현. RandomResizedCrop 은 쓰지 않음(찌그러짐).
        raise NotImplementedError("WeakCrop 은 아직 구현 전이에요 (src/augment.py TODO)")


class Degrade:
    """p 확률로 저화질 계열 중 하나만: 축소 후 확대 / 블러 / JPEG 압축."""

    def __init__(self, p=0.25):
        self.p = p

    def __call__(self, img):
        if random.random() >= self.p:
            return img
        # TODO(A1): random.choice([...]) 로 셋 중 하나. JPEG 는 io.BytesIO 에 quality 30~70 으로 저장 후 다시 열기.
        raise NotImplementedError("Degrade 는 아직 구현 전이에요 (src/augment.py TODO)")


class RandomLetterbox:
    """p 확률로 긴 변을 size*s 로 줄여 정사각형 캔버스의 무작위 위치에 놓는다. 나머지는 A 의 Letterbox 와 같다.
    s 범위: 일반 이미지 s_range, 모자이크 이미지 s_range_mosaic. 여백 색은 A 와 동일(PAD_COLOR)."""

    mosaic_aware = True

    def __init__(self, size, p=0.5, s_range=(0.6, 1.0), s_range_mosaic=(0.8, 1.0), fill=PAD_COLOR):
        self.size, self.p, self.s_range, self.s_range_mosaic, self.fill = size, p, s_range, s_range_mosaic, fill
        self.center = Letterbox(size, fill)

    def __call__(self, img, mosaic=False):
        if random.random() >= self.p:
            return self.center(img)
        # TODO(A1): s = random.uniform(*(self.s_range_mosaic if mosaic else self.s_range)); 긴 변을 round(size*s) 로 resize; Image.new 캔버스의 무작위 (x, y)에 paste
        raise NotImplementedError("RandomLetterbox 는 아직 구현 전이에요 (src/augment.py TODO)")


def build_train_steps(img_size, names):
    """train 용 단계 리스트 (ToTensor · Normalize 직전까지, TrainPipeline 으로 감싸서 사용).
    names 가 비어 있으면 베이스라인(Letterbox + 좌우반전)과 똑같다."""
    steps = []
    if "crop" in names:
        steps.append(WeakCrop())
    steps.append(transforms.RandomHorizontalFlip(p=0.5))  # 베이스라인에도 있음. 상하반전은 안 씀
    if "color" in names:
        steps.append(transforms.RandomApply([transforms.ColorJitter(0.2, 0.2, 0.2, 0.0)], p=0.5))
    if "gray" in names:
        steps.append(transforms.RandomGrayscale(p=0.15))  # letterbox 전이라 여백 색은 그대로
    if "degrade" in names:
        steps.append(Degrade())
    steps.append(RandomLetterbox(img_size) if "letterbox" in names else Letterbox(img_size))
    return steps


def build_mosaic(names):
    """'mosaic' 이 켜져 있으면 데이터셋에 넘길 Mosaic, 아니면 None."""
    return Mosaic() if "mosaic" in names else None
