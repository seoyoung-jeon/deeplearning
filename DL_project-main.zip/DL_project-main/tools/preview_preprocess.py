"""전처리 결과를 눈으로 확인: 원본과 전처리 후 이미지를 나란히 저장.

    python tools/preview_preprocess.py --image_dir data/val/images --n 12 --out preview.jpg

결과 이미지 한 줄 = 사진 한 장.
  왼쪽: 원본 (회전 보정 전, 비율 유지한 채 축소만 함) + 빨간 글씨로 원본 모드·크기
  오른쪽: 학습/추론 때 모델에 실제로 들어가는 모습 (EXIF 회전 보정 + RGB 변환 + Letterbox)
"""
import argparse
import os
import random
import sys

from PIL import Image, ImageDraw

# 이 파일은 tools/ 안에 있으므로, 한 단계 위(repo 최상위)를 import 경로에 넣어야 src 폴더를 불러올 수 있다
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data import IMAGE_EXTS, Letterbox, load_image  # noqa: E402


def main():
    # ---- 1. 명령줄 옵션 읽기 ----
    ap = argparse.ArgumentParser()
    ap.add_argument("--image_dir", required=True)            # 확인할 이미지 폴더
    ap.add_argument("--n", type=int, default=12)             # 몇 장 뽑아서 볼지
    ap.add_argument("--img_size", type=int, default=384)     # Letterbox 크기 (학습 설정과 맞추기)
    ap.add_argument("--out", default="preview.jpg")          # 저장할 결과 파일 이름
    ap.add_argument("--seed", type=int, default=0)           # 같은 seed면 매번 같은 사진이 뽑힘
    args = ap.parse_args()

    # ---- 2. 폴더에서 이미지 파일만 골라 n장 무작위로 뽑기 ----
    files = sorted(f for f in os.listdir(args.image_dir) if f.lower().endswith(IMAGE_EXTS))
    random.Random(args.seed).shuffle(files)
    files = files[:args.n]

    # ---- 3. 결과를 붙일 빈 흰색 캔버스 만들기 (가로 2칸 x 세로 n줄) ----
    cell = 256  # 한 칸 크기(px). 보기 편하게 줄여서 붙인다
    sheet = Image.new("RGB", (cell * 2, cell * len(files)), "white")
    lb = Letterbox(args.img_size)

    for r, f in enumerate(files):
        path = os.path.join(args.image_dir, f)

        # ---- 4. 왼쪽 칸: 원본 ----
        raw = Image.open(path)
        info = f"{raw.mode} {raw.size[0]}x{raw.size[1]}"  # 예: "L 300x600" (L = 흑백)
        raw = raw.convert("RGB")      # 캔버스에 붙이려고 색 형식만 맞춤 (회전 보정은 일부러 안 함)
        raw.thumbnail((cell, cell))   # 비율 유지하며 칸 크기에 맞게 축소
        sheet.paste(raw, (0, r * cell))

        # ---- 5. 오른쪽 칸: 실제 전처리 결과 ----
        # load_image = EXIF 회전 보정 + RGB 변환, lb = Letterbox (비율 유지 + 회색 여백)
        sheet.paste(lb(load_image(path)).resize((cell, cell)), (cell, r * cell))

        # ---- 6. 원본 정보 글씨 쓰기 ----
        ImageDraw.Draw(sheet).text((4, r * cell + 4), info, fill=(255, 0, 0))

    # ---- 7. 저장 ----
    sheet.save(args.out, quality=90)
    print(f"{len(files)}장 -> {args.out}  (왼쪽: 원본, 오른쪽: 전처리 후)")


if __name__ == "__main__":
    main()
