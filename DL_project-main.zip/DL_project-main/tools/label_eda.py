"""라벨 CSV EDA: 클래스 빈도, 이미지당 라벨 수, 빈 라벨, 동시출현, train/val 비율 차이.

사용법:
    python label_eda.py --train train.csv --val val.csv [--categories categories.txt] [--out eda_out]

지원하는 CSV 형식 (자동 인식):
  1) wide: 이미지 id 컬럼 + 27개 카테고리 이름 컬럼(0/1)
  2) long-string: 이미지 id 컬럼 + 라벨 컬럼 하나
     (JSON 리스트 '["jacket", "pants"]' 또는 ';' / '|' 로 구분된 문자열)
카테고리 이름에 쉼표가 들어 있으므로 쉼표 구분 문자열은 지원하지 않는다.
"""
import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

DEFAULT_CATEGORIES = [
    "shirt, blouse", "top, t-shirt, sweatshirt", "sweater", "cardigan", "jacket", "vest",
    "pants", "shorts", "skirt", "coat", "dress", "jumpsuit", "cape", "glasses", "hat",
    "headband, head covering, hair accessory", "tie", "glove", "watch", "belt", "leg warmer",
    "tights, stockings", "sock", "shoe", "bag, wallet", "scarf", "umbrella",
]


def load_categories(path):
    if path is None:
        return DEFAULT_CATEGORIES
    with open(path, encoding="utf-8") as f:
        cats = [line.strip() for line in f if line.strip()]
    assert len(cats) == 27, f"categories.txt has {len(cats)} lines, expected 27"
    return cats


def parse_label_cell(cell, categories):
    if pd.isna(cell):
        return []
    s = str(cell).strip()
    if s in ("", "[]"):
        return []
    if s.startswith("["):
        labels = json.loads(s)
    else:
        sep = ";" if ";" in s else "|"
        labels = [x.strip() for x in s.split(sep) if x.strip()]
        # 구분자가 없는 단일 라벨
        if len(labels) == 1 and labels[0] not in categories:
            raise ValueError(f"Unknown label string: {s!r}")
    unknown = [l for l in labels if l not in categories]
    if unknown:
        raise ValueError(f"Unknown labels {unknown} in {s!r}")
    return labels


def to_matrix(df, categories):
    """DataFrame -> (N x 27) 0/1 numpy 행렬."""
    if all(c in df.columns for c in categories):
        return df[categories].fillna(0).astype(int).to_numpy()
    # 라벨 문자열 컬럼 찾기: 이름 후보 우선, 없으면 마지막 object 컬럼
    candidates = [c for c in df.columns if c.lower() in ("labels", "label", "tags", "categories")]
    col = candidates[0] if candidates else df.select_dtypes("object").columns[-1]
    print(f"  label column: {col!r}")
    idx = {c: i for i, c in enumerate(categories)}
    Y = np.zeros((len(df), len(categories)), dtype=int)
    for r, cell in enumerate(df[col]):
        for l in parse_label_cell(cell, categories):
            Y[r, idx[l]] = 1
    return Y


def class_freq(Y, categories):
    n = len(Y)
    cnt = Y.sum(0)
    return pd.DataFrame({"count": cnt, "ratio": cnt / n}, index=categories)


def labels_per_image(Y):
    k = Y.sum(1)
    dist = pd.Series(k).value_counts().sort_index()
    return dist, k


def cooccurrence(Y, categories):
    C = Y.T @ Y  # C[i, j] = i와 j가 함께 나온 이미지 수
    diag = np.diag(C).astype(float)
    # P(j | i): i가 있을 때 j도 있을 확률
    with np.errstate(divide="ignore", invalid="ignore"):
        cond = np.where(diag[:, None] > 0, C / diag[:, None], 0.0)
    return (pd.DataFrame(C, index=categories, columns=categories),
            pd.DataFrame(cond, index=categories, columns=categories))


def top_pairs(C, k=20):
    cats = C.index
    rows = []
    for i in range(len(cats)):
        for j in range(i + 1, len(cats)):
            if C.iat[i, j] > 0:
                rows.append((cats[i], cats[j], int(C.iat[i, j])))
    return pd.DataFrame(rows, columns=["a", "b", "count"]).sort_values("count", ascending=False).head(k)


def plot_heatmap(M, title, path, fmt=None):
    fig, ax = plt.subplots(figsize=(12, 10))
    im = ax.imshow(M.to_numpy(), cmap="Blues")
    short = [c.split(",")[0] for c in M.index]
    ax.set_xticks(range(len(short)), short, rotation=90, fontsize=8)
    ax.set_yticks(range(len(short)), short, fontsize=8)
    ax.set_title(title)
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", required=True)
    ap.add_argument("--val", required=True)
    ap.add_argument("--categories", default=None)
    ap.add_argument("--out", default="eda_out")
    args = ap.parse_args()

    cats = load_categories(args.categories)
    os.makedirs(args.out, exist_ok=True)
    pd.set_option("display.width", 200)

    Ys = {}
    for split, path in (("train", args.train), ("val", args.val)):
        print(f"[{split}] {path}")
        Ys[split] = to_matrix(pd.read_csv(path), cats)

    # 1) 클래스별 등장 횟수
    freq = pd.concat({s: class_freq(Y, cats) for s, Y in Ys.items()}, axis=1)
    freq = freq.sort_values(("train", "count"), ascending=False)
    freq.to_csv(os.path.join(args.out, "class_freq.csv"))
    print("\n=== 1. 클래스별 등장 횟수 (train 기준 내림차순) ===")
    print(freq.round(4).to_string())
    rare = freq[freq[("train", "ratio")] < 0.01].index.tolist()
    print(f"\n희귀 클래스 (train 등장 비율 < 1%): {rare}")

    fig, ax = plt.subplots(figsize=(12, 5))
    short = [c.split(",")[0] for c in freq.index]
    ax.bar(short, freq[("train", "count")])
    ax.set_yscale("log")
    ax.set_title("train class counts (log)")
    plt.xticks(rotation=90)
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "class_freq.png"), dpi=120)
    plt.close(fig)

    # 2) 이미지당 라벨 수 + 빈 라벨
    print("\n=== 2. 이미지당 라벨 개수 ===")
    for s, Y in Ys.items():
        dist, k = labels_per_image(Y)
        empty = int((k == 0).sum())
        print(f"[{s}] 이미지 {len(Y)}장, 평균 {k.mean():.2f}개, 최대 {k.max()}개, "
              f"빈 라벨 {empty}장 ({empty / len(Y):.2%})")
        print("  분포:", {int(a): int(b) for a, b in dist.items()})
        dist.to_csv(os.path.join(args.out, f"labels_per_image_{s}.csv"), header=["n_images"])

    # 3) 동시출현 (train)
    C, cond = cooccurrence(Ys["train"], cats)
    C.to_csv(os.path.join(args.out, "cooc_count_train.csv"))
    cond.round(3).to_csv(os.path.join(args.out, "cooc_cond_prob_train.csv"))
    plot_heatmap(np.log1p(C), "train co-occurrence (log1p count)", os.path.join(args.out, "cooc_count_train.png"))
    plot_heatmap(cond, "P(col | row), train", os.path.join(args.out, "cooc_cond_prob_train.png"))
    print("\n=== 3. 동시출현 상위 20쌍 (train) ===")
    print(top_pairs(C).to_string(index=False))

    # 4) train vs val 비율 차이
    r_tr = freq[("train", "ratio")]
    r_va = freq[("val", "ratio")]
    diff = pd.DataFrame({
        "train_ratio": r_tr,
        "val_ratio": r_va,
        "diff(val-train)": r_va - r_tr,
        "rel_diff": np.where(r_tr > 0, (r_va - r_tr) / r_tr, np.nan),
    }).sort_values("diff(val-train)", key=np.abs, ascending=False)
    diff.to_csv(os.path.join(args.out, "train_val_diff.csv"))
    print("\n=== 4. train vs val 클래스 비율 차이 (절대차 큰 순) ===")
    print(diff.round(4).to_string())
    missing = [c for c in cats if freq.loc[c, ("val", "count")] == 0]
    if missing:
        print(f"\n주의: val에 한 번도 안 나오는 클래스 {missing} -> 이 클래스는 val로 threshold를 못 정함")

    print(f"\n결과 파일: {os.path.abspath(args.out)}")


if __name__ == "__main__":
    main()
