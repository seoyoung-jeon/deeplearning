"""README에 적을 총 파라미터 수 확인: python tools/count_params.py model.pt"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.model import count_params, load_checkpoint  # noqa: E402

total = 0
for path in sys.argv[1:]:
    model, ckpt = load_checkpoint(path)
    n = count_params(model)
    total += n
    print(f"{path}: {ckpt['model_name']} {n:,}")
print(f"total: {total:,} ({total / 1e6:.2f}M) {'OK' if total <= 50_000_000 else '50M 초과!'}")
