"""데이터셋 전체를 미리 한 번 전처리해서 새 폴더에 저장한다 (학습 속도 향상 + 서버 업로드 용량 감소).

    python tools/prepare_dataset.py --src data/train --dst data_prepared/train
    python tools/prepare_dataset.py --src data/val   --dst data_prepared/val

하는 일 (이미지마다):
  1) EXIF 회전 보정 + RGB 변환 (src/data.py 의 load_image 와 동일)
  2) 긴 변이 --max_side 보다 크면 비율을 유지한 채 줄이기 (작은 이미지는 키우지 않음)
  3) JPEG로 저장
Letterbox(정사각형 + 여백)는 여기서 하지 않는다. 학습 때 해상도(384/448/512)를 바꿔 실험하고,
랜덤 축소·이동 같은 augmentation도 원본 비율 이미지에 적용해야 하기 때문.

labels.csv / labels.npz / categories.txt 는 그대로 복사한다.

안전장치:
  - 중간에 끊겨도 반쯤 쓰인 파일이 남지 않는다 (.tmp로 저장 후 이름 변경). 다시 실행하면 이어서 진행.
  - 이미지 확장자(jpg/jpeg/png/webp/bmp)가 아닌 파일(Thumbs.db 등)은 무시한다.
  - 처음 실행할 때 --max_side 를 dst 폴더의 prepare_config.json 에 기록하고,
    다른 값으로 같은 폴더에 다시 실행하면 멈춘다 (크기가 섞이는 것 방지).
  - 실패한 이미지가 있으면 목록을 보여주고 에러 코드로 끝난다 (라벨과 이미지 불일치 방지).
"""
import argparse
import json
import os
import shutil
import sys
from concurrent.futures import ProcessPoolExecutor

from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data import IMAGE_EXTS, load_image  # noqa: E402

CONFIG_NAME = "prepare_config.json"


def process_one(job):
    src_path, dst_path, max_side = job
    tmp_path = dst_path + ".tmp"
    try:
        img = load_image(src_path)  # EXIF 회전 보정 + RGB 변환
        w, h = img.size
        if max(w, h) > max_side:  # 큰 이미지만 줄인다
            scale = max_side / max(w, h)
            img = img.resize((round(w * scale), round(h * scale)), Image.BICUBIC)
        # 임시 파일에 다 쓴 다음 한 번에 이름을 바꾼다 -> 중간에 끊겨도 완성된 파일만 남는다
        img.save(tmp_path, "JPEG", quality=95)
        os.replace(tmp_path, dst_path)
        return None
    except Exception as e:  # 깨진 파일 등
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        return f"{os.path.basename(src_path)}: {e}"


def check_config(dst, max_side):
    """dst 폴더가 같은 --max_side 로 만들어졌는지 확인. 처음이면 기록한다."""
    path = os.path.join(dst, CONFIG_NAME)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            prev = json.load(f)["max_side"]
        if prev != max_side:
            sys.exit(f"[중단] {dst} 는 max_side={prev} 로 만들어진 폴더입니다. "
                     f"max_side={max_side} 로 만들려면 다른 --dst 폴더를 지정하세요 (예: data_prepared_{max_side}).")
    else:
        img_dir = os.path.join(dst, "images")
        if os.path.isdir(img_dir) and os.listdir(img_dir):
            # 예전 버전 스크립트로 만든 폴더: 어떤 크기로 만들었는지 알 수 없다
            sys.exit(f"[중단] {dst} 에 이미 이미지가 있는데 {CONFIG_NAME} 이 없습니다 (예전 버전으로 만든 폴더). "
                     f"새 --dst 폴더를 쓰거나, 이 폴더가 max_side={max_side} 로 만든 게 확실하면 "
                     f'{path} 파일을 {{"max_side": {max_side}}} 내용으로 만든 뒤 다시 실행하세요.')
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"max_side": max_side}, f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)                    # 원본 split 폴더 (images/, labels.csv 가 있는 곳)
    ap.add_argument("--dst", required=True)                    # 저장할 새 폴더
    ap.add_argument("--max_side", type=int, default=640)       # 긴 변 최대 길이
    ap.add_argument("--workers", type=int, default=4)          # 동시에 처리할 프로세스 수
    args = ap.parse_args()

    src_img, dst_img = os.path.join(args.src, "images"), os.path.join(args.dst, "images")
    os.makedirs(dst_img, exist_ok=True)
    check_config(args.dst, args.max_side)

    # 지난번에 끊기면서 남은 임시 파일 정리
    for f in os.listdir(dst_img):
        if f.endswith(".tmp"):
            os.remove(os.path.join(dst_img, f))

    # 라벨 파일은 그대로 복사 (파일 이름이 바뀌지 않으므로 라벨도 그대로 맞음)
    for name in ("labels.csv", "labels.npz", "categories.txt", "README.txt"):
        if os.path.exists(os.path.join(args.src, name)):
            shutil.copy2(os.path.join(args.src, name), os.path.join(args.dst, name))

    # 이미지 파일만 대상으로, 이미 처리된 파일은 건너뛴다 (다시 실행하면 이어서 진행)
    images = sorted(f for f in os.listdir(src_img) if f.lower().endswith(IMAGE_EXTS))
    jobs = [(os.path.join(src_img, f), os.path.join(dst_img, f), args.max_side)
            for f in images if not os.path.exists(os.path.join(dst_img, f))]
    print(f"원본 이미지 {len(images)}장 중 처리할 이미지 {len(jobs)}장 -> {dst_img} (max_side={args.max_side})")

    errors = []
    with ProcessPoolExecutor(args.workers) as ex:
        for i, err in enumerate(ex.map(process_one, jobs, chunksize=64), 1):
            if err:
                errors.append(err)
            if i % 2000 == 0 or i == len(jobs):
                print(f"  {i}/{len(jobs)}")

    if errors:
        print(f"\n[경고] 실패 {len(errors)}장 - 이 이미지들은 저장되지 않았지만 labels.csv 에는 남아 있어 학습 중 에러가 납니다.")
        for e in errors:
            print("  ", e)
        print("원본 파일을 확인하거나, 해당 행을 labels.csv 에서 빼고 다시 실행하세요.")
        sys.exit(1)
    print("완료. 실패 0장")


if __name__ == "__main__":
    main()
