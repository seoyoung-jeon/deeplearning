"""val 예측 확률로 클래스별 threshold를 정하고 model.pt에 저장.

    python tune_thresholds.py --run_dir runs/baseline
"""
import argparse
import json
import os

import numpy as np
import torch

from src.data import load_categories, load_split
from src.metrics import all_metrics, per_class_f1, tune_thresholds


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", default="runs/baseline")
    ap.add_argument("--data_dir", default="data")
    args = ap.parse_args()

    ckpt_path = os.path.join(args.run_dir, "model.pt")
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cats = ckpt["categories"]
    assert cats == load_categories(os.path.join(args.data_dir, "val", "categories.txt"))
    probs = np.load(os.path.join(args.run_dir, "val_probs.npy"))
    _, targets = load_split(os.path.join(args.data_dir, "val"), cats)

    th = tune_thresholds(probs, targets)
    before = all_metrics(probs, targets, [0.5] * len(cats))
    after = all_metrics(probs, targets, th)
    print("threshold 0.5 :", json.dumps(before))
    print("tuned         :", json.dumps(after))

    f1 = per_class_f1(probs >= th[None, :], targets.astype(bool))
    for c, t, f, n in zip(cats, th, f1, targets.sum(0)):
        print(f"  {c:42s} th={t:.2f}  F1={f:.3f}  (val 양성 {int(n)}장)")

    ckpt["thresholds"] = [float(t) for t in th]
    torch.save(ckpt, ckpt_path)
    print(f"thresholds 저장 -> {ckpt_path}")


if __name__ == "__main__":
    main()
