"""학습: timm backbone + BCE/ASL.

예시:
    python train.py --model convnext_tiny.fb_in22k --img_size 384 --epochs 10 --batch_size 32
    python train.py ... --aug color,gray,degrade      # B 단계 증강 켜기 (src/augment.py)
"""
import argparse
import json
import os
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, WeightedRandomSampler
from tqdm import tqdm

from src.augment import build_mosaic, parse_aug
from src.data import LabeledImages, build_transforms, load_categories, rare_class_weights
from src.losses import build_loss
from src.metrics import all_metrics, tune_thresholds
from src.model import build_model, count_params, save_checkpoint


@torch.no_grad()
def predict_probs(model, loader, device):
    model.eval()
    probs, targets = [], []
    for x, y in tqdm(loader, desc="val", leave=False):
        probs.append(torch.sigmoid(model(x.to(device))).float().cpu().numpy())
        targets.append(y.numpy())
    return np.concatenate(probs), np.concatenate(targets)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data")
    ap.add_argument("--model", default="convnext_tiny.fb_in22k")
    ap.add_argument("--img_size", type=int, default=384)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--weight_decay", type=float, default=0.05)
    ap.add_argument("--loss", choices=["bce", "asl"], default="bce")
    ap.add_argument("--aug", default="none",
                    help="B 단계 증강, 쉼표로 구분: none | mosaic,crop,color,gray,degrade,letterbox (src/augment.py)")
    ap.add_argument("--oversample", action="store_true", help="희귀 클래스가 있는 이미지를 더 자주 뽑기")
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--no_pretrained", action="store_true", help="테스트용: ImageNet 가중치 안 받기")
    ap.add_argument("--max_steps", type=int, default=0, help="테스트용: epoch당 최대 step (0=전체)")
    ap.add_argument("--out_dir", default="runs/baseline")
    args = ap.parse_args()
    aug = parse_aug(args.aug)
    print(f"aug = {sorted(aug) or 'none (베이스라인)'}")

    os.makedirs(args.out_dir, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cats = load_categories(os.path.join(args.data_dir, "train", "categories.txt"))

    train_ds = LabeledImages(os.path.join(args.data_dir, "train"), cats, build_transforms(args.img_size, True, aug),
                             mosaic=build_mosaic(aug))
    val_ds = LabeledImages(os.path.join(args.data_dir, "val"), cats, build_transforms(args.img_size, False))
    sampler = None
    if args.oversample:
        w = rare_class_weights(train_ds.targets)
        sampler = WeightedRandomSampler(torch.from_numpy(w).double(), num_samples=len(w), replacement=True)
    train_dl = DataLoader(train_ds, args.batch_size, shuffle=sampler is None, sampler=sampler,
                          num_workers=args.num_workers, pin_memory=True, drop_last=True)
    val_dl = DataLoader(val_ds, args.batch_size, num_workers=args.num_workers, pin_memory=True)

    model = build_model(args.model, len(cats), pretrained=not args.no_pretrained).to(device)
    n_params = count_params(model)
    print(f"model={args.model} params={n_params / 1e6:.2f}M device={device}")
    assert n_params <= 50_000_000, "파라미터 50M 초과"

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    steps_per_epoch = min(len(train_dl), args.max_steps) if args.max_steps else len(train_dl)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=args.lr, total_steps=args.epochs * steps_per_epoch,
                                                pct_start=0.1)
    criterion = build_loss(args.loss)
    scaler = torch.amp.GradScaler(enabled=device == "cuda")

    best, history = -1.0, []
    for epoch in range(1, args.epochs + 1):
        model.train()
        t0, total = time.time(), 0.0
        for step, (x, y) in enumerate(tqdm(train_dl, desc=f"epoch {epoch}", total=steps_per_epoch)):
            if step >= steps_per_epoch:
                break
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            with torch.autocast(device_type=device, enabled=device == "cuda"):
                loss = criterion(model(x), y)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            sched.step()
            total += loss.item()

        probs, targets = predict_probs(model, val_dl, device)
        m05 = all_metrics(probs, targets, [0.5] * len(cats))
        th = tune_thresholds(probs, targets)
        mtuned = all_metrics(probs, targets, th)
        row = {"epoch": epoch, "train_loss": total / steps_per_epoch, "sec": round(time.time() - t0),
               "val@0.5": m05, "val@tuned": mtuned}
        history.append(row)
        print(json.dumps(row, ensure_ascii=False))

        # 모델 선택 기준: threshold 0.5에서 세 F1의 평균 (튜닝된 값은 val에 과적합될 수 있음)
        score = np.mean(list(m05.values()))
        if score > best:
            best = score
            save_checkpoint(os.path.join(args.out_dir, "model.pt"), model, args.model, args.img_size,
                            cats, [0.5] * len(cats))
            np.save(os.path.join(args.out_dir, "val_probs.npy"), probs)
            print(f"  -> best 갱신 (mean F1@0.5 = {score:.4f}), 저장")

    with open(os.path.join(args.out_dir, "history.json"), "w", encoding="utf-8") as f:
        json.dump({"args": vars(args), "params": n_params, "history": history}, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
