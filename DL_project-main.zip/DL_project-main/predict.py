"""제출용 추론. 인터넷 없이 동작.

    python predict.py --input_dir TEST_IMAGES --output predictions.jsonl
"""
import argparse
import json

import torch
from torch.utils.data import DataLoader

from src.data import FolderImages, build_transforms
from src.model import load_checkpoint


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_dir", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--model", default="model.pt")
    ap.add_argument("--batch_size", type=int, default=32)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, ckpt = load_checkpoint(args.model, device)
    cats, th = ckpt["categories"], torch.tensor(ckpt["thresholds"])

    ds = FolderImages(args.input_dir, build_transforms(ckpt["img_size"], train=False))
    dl = DataLoader(ds, args.batch_size, num_workers=2)

    n = 0
    with open(args.output, "w", encoding="utf-8") as f, torch.no_grad():
        for x, ids in dl:
            x = x.to(device)
            # 좌우 반전 TTA (파라미터 추가 없음)
            probs = (torch.sigmoid(model(x)) + torch.sigmoid(model(torch.flip(x, dims=[3])))).cpu() / 2
            for test_id, p in zip(ids, probs):
                labels = [cats[c] for c in range(len(cats)) if p[c] >= th[c]]
                f.write(json.dumps({"test_id": test_id, "labels": labels}, ensure_ascii=False) + "\n")
                n += 1
    print(f"{n}장 예측 -> {args.output}")


if __name__ == "__main__":
    main()
