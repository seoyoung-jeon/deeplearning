# 팀 폴더 구조

> 내 PC든 학교 서버든 repo 안쪽은 아래와 똑같이 맞춥니다.
> 표시: **[GitHub]** repo로 공유 · **[로컬만]** 각자 PC·서버에만, 업로드 금지 · **[자동]** 스크립트가 만듦 · **[예정]** 아직 없음

```
DL_project/                                   repo 최상위. VS Code에서 이 폴더를 Open Folder
├── train.py                                  [GitHub] 학습 (B)
├── tune_thresholds.py                        [GitHub] 클래스별 threshold, 원본 val로만 (C)
├── predict.py                                [GitHub] 제출용 추론 (C)
├── requirements.txt · README.md · .gitignore [GitHub]
├── src/                                      [GitHub] 공통 모듈
│   ├── data.py                               A 전처리, B 증강, 데이터셋 (A1)
│   ├── losses.py · model.py                  BCE/ASL, timm 모델 (B, C)
│   └── metrics.py                            F1 3종, threshold 탐색 (B, C)
├── tools/                                    [GitHub] 한 번씩 돌리는 스크립트
│   ├── prepare_dataset.py                    사전 리사이즈 (max_side 640)
│   ├── preview_preprocess.py · label_eda.py  전처리 미리보기, 라벨 EDA
│   └── count_params.py                       50M 이하 확인
├── docs/                                     [GitHub] 계획 문서, 실험 기록
│
├── data/                                     [로컬만] LMS 원본 그대로. 지우지 않기
│   ├── train/   images/ labels.csv labels.npz categories.txt     45,622장
│   ├── val/     images/ labels.csv labels.npz categories.txt     1,158장
│   ├── examples/                             30장. 눈으로 오류 분석만
│   ├── test_public/                          300장. 추론 동작 확인만, 튜닝 금지
│   └── negative/  train/ val/                [예정] 옷 없는 사진 (A2). train과 val 겹치지 않게
│
├── data_prepared/                            [로컬만] 학습은 이 폴더로 (--data_dir data_prepared)
│   ├── train/   images/ labels.csv … prepare_config.json         긴 변 640, 실패 0장
│   ├── val/     images/ labels.csv … prepare_config.json         원본 val. 모델 선택·threshold 기준
│   ├── val_shifted/                          [예정] 흑백·가로형·저화질 고정 변형 사본
│   └── negative_val/                         [예정] 오탐률 측정용 약 200장
│
├── runs/                                     [자동][로컬만] 실험 결과
│   └── e01_convnext_t_384_bce/               model.pt, val_probs.npy, history.json
└── eda_out/ · preview.jpg                    [자동] EDA 결과, 미리보기
```

## 지켜야 할 규칙

1. **데이터는 GitHub에 올리지 않아요.** `data/`, `data_prepared*/`, `runs/`, 이미지, `*.pt`는 `.gitignore`가 막고 있어요. 그래도 `git add .` 대신 파일을 골라서 add 해요.
2. **repo 안의 상대 경로만 써요.** 코드에 `C:\Users\…` 같은 내 컴퓨터 경로를 적지 않아요. 그래야 다른 팀원 PC와 학교 서버에서 그대로 돌아가요.
3. **팀 전체가 같은 `data_prepared`(640)를 써요.** 크기를 바꿔야 하면 새 폴더(`data_prepared_724` 등)를 만들고 팀에 공지해요.
4. **원본 `data/`는 지우지 않아요.** 전처리를 다시 해야 할 때 필요해요.
5. **repo 폴더가 두 겹이면 안쪽을 열어요.** `train.py`가 보이는 폴더가 기준이에요.

## 내 PC와 학교 서버

| | 내 PC (Windows) | 학교 서버 (Linux) |
| --- | --- | --- |
| 위치 예시 | `Desktop\dalpha\DL_project\` | `~/DL_project/` |
| 하는 일 | 코드 수정, 전처리, 미리보기, smoke test | 본 학습 |
| 코드 | `git clone` / `git pull` | `git clone` / `git pull` |
| 데이터 | LMS zip을 `data/`에 풀고 `data_prepared` 생성 | `data_prepared`만 `scp -r`로 올리고 `chmod -R go-rwx data_prepared` |

## 실험 폴더 이름 규칙

`runs/e번호_모델_해상도_변경점` 형식으로 `train.py --out_dir`에 넣어요. 번호는 팀 스프레드시트에서 먼저 잡고, 한 실험에서는 한 가지만 바꿔요.

| 예시 | 뜻 |
| --- | --- |
| `runs/e01_convnext_t_384_bce` | 베이스라인 (A만) |
| `runs/e02_convnext_t_384_color` | + ColorJitter·흑백·저화질 |
| `runs/e03_effv2s_384_bce` | backbone 비교 |
| `runs/e04_convnext_t_512_color` | 해상도 비교 |
