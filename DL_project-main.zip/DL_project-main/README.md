# MAT4091 Fashion Category Tagging (팀 repo)

이미지 한 장에서 27개 의류·액세서리 카테고리를 모두 찾는 multi-label 분류 프로젝트입니다. (Dalpha 협업, 파라미터 50M 이하)

> ⚠️ **데이터는 이 repo에 절대 올리지 않습니다.** 과제 이용 규정상 데이터셋 일부라도 GitHub 등에 업로드 금지입니다.
> `.gitignore`가 `data/`, `data_prepared/`, 이미지, `labels.csv`, `*.npz`, `*.pt`를 막고 있지만, `git add .` 대신 파일을 골라서 add 하고 커밋 전에 `git status`로 한 번 더 확인하세요.

## 문서

| 문서 | 내용 |
| --- | --- |
| [docs/FOLDER_STRUCTURE.md](docs/FOLDER_STRUCTURE.md) | 팀 공통 폴더 구조, 업로드 규칙, 실험 폴더 이름 규칙 |
| [docs/PREPROCESSING.md](docs/PREPROCESSING.md) | 전처리 · augmentation 계획 (A~D 단계) |

## 1. 처음 세팅 (각자 1회)

```bash
git clone https://github.com/8309jjy-collab/DL_project.git
cd DL_project

# GPU가 있으면 먼저 https://pytorch.org 에서 본인 CUDA에 맞는 torch 설치 명령을 실행
python -m pip install -r requirements.txt
```

> Windows + conda에서 `python`이 다른 환경을 잡으면 환경 경로를 직접 쓰세요.
> 예: `& C:\Users\USER\anaconda3\envs\univ\python.exe -m pip install -r requirements.txt`

LMS에서 받은 zip을 풀어서 repo 안에 아래처럼 둡니다. zip 안의 `MAT4091_fashion_train/train` 폴더를 `data/train`으로 옮기면 됩니다 (나머지도 동일).

```
data/
  train/        categories.txt  images/  labels.csv  labels.npz   (45,622장)
  val/          categories.txt  images/  labels.csv  labels.npz   (1,158장)
  examples/     30장 예시 - 눈으로 오류 분석만
  test_public/  300장 - 추론 코드 동작 확인만, 학습·튜닝 금지
```

## 2. 파일 구조

| 파일 | 내용 | 주 담당 |
| --- | --- | --- |
| `src/data.py` | A 전처리(EXIF 회전, RGB, Letterbox), 데이터셋 | A1 |
| `src/augment.py` | B 단계 증강 (`--aug`로 켜기, 뼈대 + TODO) | A1 |
| `src/losses.py` | BCE / ASL | C |
| `src/metrics.py` | Micro / Macro / Image-wise F1, 클래스별 threshold 탐색 | B, C |
| `src/model.py` | timm 모델 생성, 체크포인트 저장/로드 | B |
| `train.py` | 학습 | B |
| `tune_thresholds.py` | val로 클래스별 threshold 결정 → model.pt에 저장 | C |
| `predict.py` | 제출 형식 추론 (`predictions.jsonl`) | C |
| `tools/prepare_dataset.py` | 사전 리사이즈 (긴 변 640) | A1 |
| `tools/preview_preprocess.py` | 전처리 결과 미리보기 | A1 |
| `tools/label_eda.py` | 라벨 EDA | A1 |
| `tools/count_params.py` | 파라미터 수 확인 (50M 이하) | 공통 |

## 3. 실행 순서

```bash
# 1) 사전 리사이즈 (한 번만. 팀 전체가 같은 data_prepared 사용)
python tools/prepare_dataset.py --src data/train --dst data_prepared/train
python tools/prepare_dataset.py --src data/val   --dst data_prepared/val

# 2) 전처리 미리보기 (왼쪽 원본, 오른쪽 모델 입력)
python tools/preview_preprocess.py --image_dir data_prepared/val/images --n 12 --out preview.jpg

# 3) smoke test (CPU에서 몇 분, 코드가 끝까지 도는지만 확인)
python train.py --data_dir data_prepared --model resnet18 --img_size 224 --epochs 1 --max_steps 20 \
    --batch_size 8 --num_workers 0 --out_dir runs/smoke_test

# 4) 베이스라인 (학교 서버, ConvNeXt-Tiny 27.8M)
python train.py --data_dir data_prepared --model convnext_tiny.fb_in22k --img_size 384 --epochs 10 \
    --batch_size 32 --out_dir runs/e01_convnext_t_384_bce

# 5) 클래스별 threshold 튜닝 (원본 val로만)
python tune_thresholds.py --data_dir data_prepared --run_dir runs/e01_convnext_t_384_bce

# 6) 제출 형식 추론 확인 (public test는 동작 확인만!)
cp runs/e01_convnext_t_384_bce/model.pt model.pt
python predict.py --input_dir data/test_public/images --output predictions.jsonl
python tools/count_params.py model.pt
```

학습 중 epoch마다 val의 세 F1이 threshold 0.5 기준과 튜닝 기준으로 같이 출력되고, `runs/<이름>/history.json`에 기록됩니다.

### 실험 폴더 이름 규칙

`runs/e번호_모델_해상도_변경점` 형식으로 `--out_dir`에 넣습니다. 번호는 팀 스프레드시트에서 먼저 잡고, 한 실험에서는 한 가지만 바꿉니다.

| 예시 | 뜻 |
| --- | --- |
| `runs/e01_convnext_t_384_bce` | 베이스라인 (A 전처리만) |
| `runs/e02_convnext_t_384_asl` | loss만 ASL로 |
| `runs/e03_convnext_t_384_asl_os` | + 희귀 클래스 oversampling (`--oversample`) |
| `runs/e04_effv2s_384_asl` | backbone 비교 (`tf_efficientnetv2_s.in21k`, 20.2M) |
| `runs/e05_effv2s_512_asl` | 해상도 비교 |

B 단계 augmentation은 `src/augment.py`에 있고 `--aug`로 켭니다. `--aug none`(기본값)이 베이스라인이고, 예: `--aug color,gray,degrade`. 실험 순서는 [docs/PREPROCESSING.md](docs/PREPROCESSING.md)를 따릅니다.

## 4. 학교 서버에서 돌리기

```bash
nvidia-smi                      # GPU 종류·메모리, 다른 사람이 쓰는 중인지 확인
python -c "import torch; print(torch.cuda.is_available(), torch.version.cuda)"
```

- **코드**: 서버에서 `git clone` (데이터는 git에 없음)
- **데이터**: PC에서 만든 `data_prepared` 폴더만 `scp -r`로 올리고, `chmod -R go-rwx data_prepared`로 본인 외 접근을 막으세요 (과제 규정: 비공개 환경에서만 사용).
- **접속이 끊겨도 학습 유지**: `tmux new -s train` 안에서 실행하고 `Ctrl+b d`로 나오기, 다시 볼 때 `tmux attach -t train`.
  tmux가 없으면 `nohup python train.py ... > runs/log_e01.txt 2>&1 &` 후 `tail -f runs/log_e01.txt`.
- **GPU가 여러 개인 공용 서버**: `CUDA_VISIBLE_DEVICES=0 python train.py ...`처럼 비어 있는 GPU 하나만 지정.
- **서버에 인터넷이 막혀 있으면**: ImageNet 가중치를 못 받습니다. 인터넷 되는 PC에서
  `python -c "import timm; timm.create_model('convnext_tiny.fb_in22k', pretrained=True)"`로 받은 뒤
  `~/.cache/huggingface/hub/models--timm--convnext_tiny.fb_in22k` 폴더를 서버의 같은 위치로 복사하세요.
- **GPU 메모리 기준 batch size (ConvNeXt-T, 384px, 대략)**: 24GB → 48, 12GB → 24, 8GB → 16. `CUDA out of memory`가 나면 절반으로.

## 5. 협업 규칙

- 작업 시작 전 `git pull`, 끝나면 `git add <파일>` → `git commit -m "무엇을 했는지"` → `git push`
- 코드에 `C:\Users\...` 같은 내 컴퓨터 경로를 적지 않고 repo 기준 상대 경로만 사용
- 큰 변경은 브랜치를 따서 작업하고 Pull Request로 합치기

## 6. 제출 체크리스트 (나중에)

- [ ] `python predict.py --input_dir TEST_IMAGES --output predictions.jsonl` 이 인터넷 없이 동작
- [ ] 이미지마다 한 줄, `test_id`는 확장자 뺀 파일명, 라벨 없으면 `[]`
- [ ] 총 파라미터 50M 이하, README에 명시
- [ ] threshold는 train/val로만 결정
